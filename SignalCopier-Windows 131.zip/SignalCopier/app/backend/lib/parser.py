"""Strict signal parser: only the channel's exact template is traded.

Currency Pair: AED/CNY OTC
Timeframe: 1 minute
Time: 13:40
Direction: SELL

All four labeled fields are required. Anything else (results, ads, recaps, free text) is ignored.
"""

import re

from models.schemas import ParsedSignal

CODES = set("""
AED AFN ALL AMD ANG AOA ARS AUD AWG AZN BAM BBD BDT BGN BHD BIF BMD BND BOB BRL BSD BTN BWP BYN BZD CAD CDF CHF
CLP CNY CNH COP CRC CUP CVE CZK DJF DKK DOP DZD EGP ERN ETB EUR FJD GBP GEL GHS GIP GMD GNF GTQ GYD HKD HNL HTG
HUF IDR ILS INR IQD IRR ISK JMD JOD JPY KES KGS KHR KMF KRW KWD KYD KZT LAK LBP LKR LRD LSL LYD MAD MDL MGA MKD
MMK MNT MOP MRU MUR MVR MWK MXN MYR MZN NAD NGN NIO NOK NPR NZD OMR PAB PEN PGK PHP PKR PLN PYG QAR RON RSD RUB
RWF SAR SBD SCR SDG SEK SGD SHP SLL SOS SRD SSP STN SYP SZL THB TJS TMT TND TOP TRY TTD TWD TZS UAH UGX USD USDT
UYU UZS VES VND VUV WST XAF XCD XOF XPF YER ZAR ZMW ZWL XAU XAG XPT XPD
BTC ETH LTC XRP BNB SOL DOGE ADA DOT TRX MATIC LINK AVAX TON SHIB BCH DASH XLM ATOM UNI ETC
""".split())

PAIR_LINE = re.compile(r"^\W*(?:currency\s*pair|pair|asset|الزوج)\s*[:：\-]\s*(.+)$", re.I | re.M)
TF_LINE = re.compile(
    r"^\W*(?:timeframe|time\s*frame|expiration|expiry|الفريم|المدة)\s*[:：\-]\s*"
    r"(\d{1,3})\s*(seconds?|secs?|s|minutes?|mins?|min|m|hours?|h|ثانية|ثواني|دقيقة|دقائق|ساعة)?\s*$",
    re.I | re.M,
)
TF_M = re.compile(r"^\W*(?:timeframe|time\s*frame|expiration|expiry|الفريم|المدة)\s*[:：\-]\s*([MHS])(\d{1,3})\s*$", re.I | re.M)
TIME_LINE = re.compile(r"^\W*(?:time|entry\s*time|الوقت|وقت\s*الدخول)\s*[:：\-]\s*(\d{1,2})[:.](\d{2})\s*$", re.I | re.M)
DIR_LINE = re.compile(r"^\W*(?:direction|الاتجاه|الإتجاه)\s*[:：\-]\s*(.+)$", re.I | re.M)
CALL = re.compile(r"\b(BUY|CALL)\b|شراء", re.I)
PUT = re.compile(r"\b(SELL|PUT)\b|بيع", re.I)
SLASH = re.compile(r"^\W*([A-Za-z]{3,5})\s*/\s*([A-Za-z]{3,5})\s*(?:[-_ ]?\s*\(?\s*(OTC)\s*\)?)?\W*$", re.I)
RESULT = re.compile(
    r"\b(WIN|WINS|WON|LOSS|LOSSES|LOST|RESULTS?|RECAP|REPORT|PROFIT|ITM|OTM|DOJI|REFUND|CLOSED)\b"
    r"|نتيجة|نتائج|خسارة|ربح|تقرير|إحصائيات|احصائيات|✅|❌|☑|✔|✖",
    re.I,
)


def _ignored(why: str) -> ParsedSignal:
    return ParsedSignal(kind="ignored", explanation=why)


def _unit(u: str | None) -> int:
    u = (u or "m").lower()
    if u.startswith("s") or u in ("ثانية", "ثواني"):
        return 1
    if u.startswith("h") or u == "ساعة":
        return 3600
    return 60


def _pair(value: str) -> tuple[str, str] | None:
    m = SLASH.match(value.strip())
    if not m:
        return None
    base, quote = m.group(1).upper(), m.group(2).upper()
    if base not in CODES or quote not in CODES or base == quote:
        return None
    otc = bool(m.group(3))
    return f"{base}{quote}{'_otc' if otc else ''}", f"{base}/{quote}{' OTC' if otc else ''}"


def parse_signal(text: str) -> ParsedSignal:
    if RESULT.search(text):
        return _ignored("رسالة نتائج/إعلان — لا تُعتبر توصية")
    p, d, t = PAIR_LINE.search(text), DIR_LINE.search(text), TIME_LINE.search(text)
    tf, tfm = TF_LINE.search(text), TF_M.search(text)
    if not (p and d and t and (tf or tfm)):
        return _ignored("ليست توصية كاملة (يلزم: Currency Pair و Timeframe و Time و Direction)")
    pair = _pair(p.group(1))
    if not pair:
        return _ignored(f"الزوج غير مفهوم: {p.group(1).strip()}")
    v = d.group(1)
    is_call, is_put = bool(CALL.search(v)), bool(PUT.search(v))
    if is_call == is_put:
        return _ignored(f"الاتجاه غير واضح: {v.strip()}")
    direction = "call" if is_call else "put"
    if tf:
        duration = int(tf.group(1)) * _unit(tf.group(2))
    else:
        duration = int(tfm.group(2)) * {"S": 1, "M": 60, "H": 3600}[tfm.group(1).upper()]
    if not 5 <= duration <= 4 * 3600:
        return _ignored("مدة الصفقة غير صالحة")
    hh, mm = int(t.group(1)), int(t.group(2))
    if hh > 23 or mm > 59:
        return _ignored("الوقت غير صالح")
    entry = f"{hh:02d}:{mm:02d}"
    dir_ar = {"call": "BUY (شراء)", "put": "SELL (بيع)"}[direction]
    return ParsedSignal(
        kind="full", asset=pair[0], pair_label=pair[1], direction=direction, duration=duration,
        entry_time=entry, explanation=f"توصية: {dir_ar} على {pair[1]} لمدة {duration // 60 or duration} {'دقيقة' if duration >= 60 else 'ثانية'} في الساعة {entry}",
    )
