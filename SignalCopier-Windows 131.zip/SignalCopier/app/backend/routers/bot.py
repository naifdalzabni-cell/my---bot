from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException

from lib.dates import today_iso
from lib.db import db
from lib.parser import parse_signal
from models.schemas import (
    ChannelRule,
    ChannelRuleIn,
    ChannelStat,
    ChatSelection,
    Dialog,
    FavoritesIn,
    ParsedSignal,
    ParseRequest,
    PocketConnect,
    PocketMode,
    PocketStatus,
    QrStatus,
    Settings,
    Signal,
    StatusOut,
    Stats,
    TelegramPassword,
    TelegramSendCode,
    TelegramStatus,
    TelegramVerify,
    TelegramVerifyResult,
    Trade,
)
from services import engine
from services.pocket import pocket
from services.telegram import TgError, telegram

router = APIRouter()


def _aware(doc: dict, *keys: str) -> dict:
    for k in keys:
        v = doc.get(k)
        if isinstance(v, datetime) and v.tzinfo is None:
            doc[k] = v.replace(tzinfo=timezone.utc)
    return doc


# ---------- status / settings ----------
@router.get("/status", response_model=StatusOut)
async def get_status():
    s = await engine.get_settings()
    return StatusOut(
        telegram=TelegramStatus(**telegram.status()),
        pocket=PocketStatus(**await pocket.status()),
        bot_enabled=s.bot_enabled,
        server_time=datetime.now(timezone.utc),
    )


@router.get("/settings", response_model=Settings)
async def get_settings():
    return await engine.get_settings()


@router.put("/settings", response_model=Settings)
async def put_settings(body: Settings):
    if body.amount <= 0:
        raise HTTPException(400, "مبلغ الدخول يجب أن يكون أكبر من صفر")
    if body.martingale_steps < 0 or body.martingale_steps > 10:
        raise HTTPException(400, "عدد خطوات المضاعفة بين 0 و 10")
    return await engine.save_settings(body)


# ---------- telegram ----------
@router.post("/telegram/send-code")
async def tg_send_code(body: TelegramSendCode):
    try:
        await telegram.send_code(body.api_id, body.api_hash, body.phone)
    except TgError as exc:
        raise HTTPException(400, str(exc)) from exc
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(400, f"تعذّر إرسال الكود: {exc}") from exc
    return {"ok": True}


@router.post("/telegram/verify", response_model=TelegramVerifyResult)
async def tg_verify(body: TelegramVerify):
    try:
        ok = await telegram.verify(body.code, body.password)
    except TgError as exc:
        raise HTTPException(400, str(exc)) from exc
    return TelegramVerifyResult(ok=ok, needs_password=not ok)


@router.get("/telegram/dialogs", response_model=list[Dialog])
async def tg_dialogs(refresh: bool = False):
    try:
        return await telegram.dialogs(refresh)
    except TgError as exc:
        raise HTTPException(409, str(exc)) from exc


@router.post("/telegram/qr/start", response_model=QrStatus)
async def tg_qr_start():
    try:
        await telegram.qr_start()
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(400, f"تعذّر إنشاء رمز QR: {exc}") from exc
    return QrStatus(**telegram.qr_status())


@router.get("/telegram/qr", response_model=QrStatus)
async def tg_qr_status():
    return QrStatus(**telegram.qr_status())


@router.post("/telegram/password", response_model=TelegramStatus)
async def tg_password(body: TelegramPassword):
    try:
        await telegram.submit_password(body.password)
    except TgError as exc:
        raise HTTPException(400, str(exc)) from exc
    return TelegramStatus(**telegram.status())


@router.put("/telegram/favorites", response_model=TelegramStatus)
async def tg_favorites(body: FavoritesIn):
    await telegram.set_favorites(body.ids)
    return TelegramStatus(**telegram.status())


@router.put("/telegram/chats", response_model=TelegramStatus)
async def tg_chats(body: ChatSelection):
    await telegram.set_chats([c.model_dump() for c in body.chats])
    return TelegramStatus(**telegram.status())


@router.post("/telegram/logout", response_model=TelegramStatus)
async def tg_logout():
    await telegram.logout()
    return TelegramStatus(**telegram.status())


# ---------- pocket option ----------
@router.post("/pocket/connect", response_model=PocketStatus)
async def po_connect(body: PocketConnect):
    try:
        await pocket.connect(body.ssid)
    except RuntimeError as exc:
        raise HTTPException(400, str(exc)) from exc
    return PocketStatus(**await pocket.status())


@router.post("/pocket/mode", response_model=PocketStatus)
async def po_mode(body: PocketMode):
    try:
        await pocket.switch_mode(body.mode)
    except RuntimeError as exc:
        raise HTTPException(400, str(exc)) from exc
    return PocketStatus(**await pocket.status())


@router.post("/pocket/disconnect", response_model=PocketStatus)
async def po_disconnect():
    await pocket.disconnect()
    return PocketStatus(**await pocket.status())


# ---------- signals / trades / stats ----------
@router.post("/parse", response_model=ParsedSignal)
async def parse(body: ParseRequest):
    return parse_signal(body.text)


@router.get("/signals", response_model=list[Signal])
async def signals(limit: int = 50):
    rows = await db.signals.find({}, {"_id": 0}).sort("received_at", -1).to_list(min(limit, 200))
    return [_aware(r, "received_at") for r in rows]


@router.get("/trades", response_model=list[Trade])
async def trades(limit: int = 100):
    rows = await db.trades.find({}, {"_id": 0}).sort("opened_at", -1).to_list(min(limit, 500))
    return [_aware(r, "opened_at", "closed_at") for r in rows]


@router.get("/stats", response_model=Stats)
async def stats():
    day = today_iso()
    rows = await db.trades.find({"day": day}, {"_id": 0, "status": 1, "profit": 1, "latency_ms": 1, "opened_at": 1}).to_list(5000)
    lat = [r for r in rows if r.get("latency_ms") is not None]
    lat.sort(key=lambda r: r["opened_at"])
    wins = sum(1 for r in rows if r["status"] == "win")
    losses = sum(1 for r in rows if r["status"] == "loss")
    draws = sum(1 for r in rows if r["status"] == "draw")
    pending = sum(1 for r in rows if r["status"] == "pending")
    decided = wins + losses
    return Stats(
        day=day,
        pnl=round(sum(r.get("profit", 0) for r in rows), 2),
        wins=wins, losses=losses, draws=draws, pending=pending,
        win_rate=round(wins * 100 / decided, 1) if decided else 0,
        trades_count=len(rows),
        signals_count=await db.signals.count_documents({"day": day}),
        avg_latency_ms=int(sum(r["latency_ms"] for r in lat) / len(lat)) if lat else None,
        last_latency_ms=lat[-1]["latency_ms"] if lat else None,
    )


# ---------- per-channel rules & performance ----------
@router.get("/channel-rules", response_model=list[ChannelRule])
async def list_rules():
    return [ChannelRule(chat_id=k, **{f: v for f, v in r.items() if f != "chat_id"}) for k, r in (await engine.get_rules()).items()]


@router.put("/channel-rules/{chat_id}", response_model=ChannelRule)
async def put_rule(chat_id: int, body: ChannelRuleIn):
    await db.config.update_one(
        {"id": "channel_rules"}, {"$set": {"id": "channel_rules", f"rules.{chat_id}": body.model_dump()}}, upsert=True
    )
    engine.invalidate_rules()
    return ChannelRule(chat_id=chat_id, **body.model_dump())


@router.delete("/channel-rules/{chat_id}")
async def delete_rule(chat_id: int):
    await db.config.update_one({"id": "channel_rules"}, {"$unset": {f"rules.{chat_id}": ""}})
    engine.invalidate_rules()
    return {"ok": True}


@router.get("/channel-stats", response_model=list[ChannelStat])
async def channel_stats():
    rules = await engine.get_rules()
    titles = {c["id"]: c["title"] for c in telegram.status()["selected_chats"]}
    trades_rows = await db.trades.find(
        {"chat_id": {"$ne": None}}, {"_id": 0, "chat_id": 1, "chat_title": 1, "signal_id": 1, "step": 1, "status": 1, "profit": 1}
    ).to_list(20000)
    sig_counts = {
        r["_id"]: r["n"]
        for r in await db.signals.aggregate([{"$group": {"_id": "$chat_id", "n": {"$sum": 1}}}]).to_list(1000)
    }
    by_chat: dict[int, list[dict]] = {}
    for t in trades_rows:
        by_chat.setdefault(t["chat_id"], []).append(t)
        titles.setdefault(t["chat_id"], t.get("chat_title") or str(t["chat_id"]))
    out = []
    for cid, title in titles.items():
        rows = by_chat.get(cid, [])
        wins = sum(1 for r in rows if r["status"] == "win")
        losses = sum(1 for r in rows if r["status"] == "loss")
        draws = sum(1 for r in rows if r["status"] == "draw")
        chains: dict[str, list[dict]] = {}
        for r in rows:
            chains.setdefault(r.get("signal_id") or id(r), []).append(r)
        decided = [c for c in chains.values() if not any(x["status"] == "pending" for x in c)
                   and any(x["status"] in ("win", "loss") for x in c)]
        first_win = sum(1 for c in decided if any(x["step"] == 0 and x["status"] == "win" for x in c))
        chain_win = sum(1 for c in decided if any(x["status"] == "win" for x in c))
        out.append(ChannelStat(
            chat_id=cid, chat_title=title, signals=sig_counts.get(cid, 0), trades=len(rows),
            wins=wins, losses=losses, draws=draws,
            win_rate=round(wins * 100 / (wins + losses), 1) if wins + losses else 0,
            first_entry_win_rate=round(first_win * 100 / len(decided), 1) if decided else 0,
            chain_win_rate=round(chain_win * 100 / len(decided), 1) if decided else 0,
            pnl=round(sum(r.get("profit", 0) for r in rows), 2),
            has_rule=cid in rules,
        ))
    out.sort(key=lambda x: (x.trades == 0, -x.chain_win_rate, -x.pnl))
    return out
