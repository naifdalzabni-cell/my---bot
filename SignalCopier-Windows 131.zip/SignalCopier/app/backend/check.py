"""Pre-flight check: writes an Arabic report (check-report.txt) of what is missing and how to fix it."""

import importlib
import os
import socket
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent.parent
REPORT = BASE / "check-report.txt"
lines: list[str] = []
problems = 0


def ok(msg: str) -> None:
    lines.append(f"[تم]   {msg}")


def bad(msg: str, fix: str) -> None:
    global problems
    problems += 1
    lines.append(f"[خطأ]  {msg}")
    lines.append(f"       الحل: {fix}")


def tcp(host: str, port: int, timeout: float = 5) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def check_python() -> None:
    v = sys.version_info
    if v >= (3, 10):
        ok(f"بايثون موجود (الإصدار {v.major}.{v.minor})")
    else:
        bad(f"إصدار بايثون قديم ({v.major}.{v.minor})", "شغّل install.bat مرة أخرى ليثبّت Python 3.11")


PACKAGES = {
    "fastapi": "لوحة التحكم", "uvicorn": "خادم لوحة التحكم", "motor": "الاتصال بقاعدة البيانات",
    "pymongo": "قاعدة البيانات", "pydantic": "الإعدادات", "dotenv": "ملف الإعدادات",
    "tzdata": "التوقيت", "telethon": "تيليجرام", "BinaryOptionsToolsV2": "Pocket Option",
}


def check_packages() -> bool:
    missing = []
    for mod, what in PACKAGES.items():
        try:
            importlib.import_module(mod)
        except Exception as exc:  # noqa: BLE001
            missing.append(f"{mod} ({what}): {exc}")
    if not missing:
        ok("كل البرامج المساعدة مثبتة")
        return True
    for m in missing:
        bad(f"برنامج ناقص أو تالف: {m}", "تأكد من الإنترنت ثم شغّل install.bat مرة أخرى")
    return False


def check_env() -> None:
    env = ROOT / ".env"
    if not env.exists():
        bad("ملف الإعدادات app\\backend\\.env غير موجود", "شغّل install.bat مرة أخرى")
        return
    from dotenv import dotenv_values

    vals = dotenv_values(env)
    need = [k for k in ("MONGO_URL", "DB_NAME") if not vals.get(k)]
    if need:
        bad(f"ملف الإعدادات ناقص: {', '.join(need)}", "شغّل install.bat مرة أخرى")
    else:
        ok("ملف الإعدادات سليم")
    web = vals.get("SERVE_FRONTEND_DIR")
    if not web or not Path(web).is_dir():
        bad("ملفات لوحة التحكم (app\\web) غير موجودة", "انسخ مجلد البوت كاملاً ثم شغّل install.bat")
    else:
        ok("ملفات لوحة التحكم موجودة")
    os.environ.update({k: v for k, v in vals.items() if v})


def check_mongo() -> None:
    try:
        from pymongo import MongoClient

        MongoClient(os.environ.get("MONGO_URL", "mongodb://127.0.0.1:27017"), serverSelectionTimeoutMS=4000).admin.command("ping")
        ok("قاعدة البيانات MongoDB تعمل")
    except Exception:  # noqa: BLE001
        bad("قاعدة البيانات MongoDB لا تعمل",
            "شغّل install.bat مرة أخرى (سيثبّت نسخة متوافقة مع الـ VPS). إن استمرت: افتح services.msc وشغّل خدمة MongoDB")


def check_port() -> None:
    if tcp("127.0.0.1", int(os.environ.get("PORT", "8001")), 1):
        lines.append("[تنبيه] المنفذ 8001 مستخدم — إما أن البوت يعمل الآن، أو برنامج آخر يستخدمه")
    else:
        ok("المنفذ 8001 متاح")


def check_internet() -> None:
    if tcp("149.154.167.51", 443) or tcp("149.154.175.50", 443):
        ok("الاتصال بتيليجرام يعمل")
    else:
        bad("لا يمكن الوصول إلى تيليجرام", "تأكد من إنترنت الـ VPS، أو أن مزوّد الـ VPS لا يحظر تيليجرام")
    if tcp("pocketoption.com", 443):
        ok("الاتصال بـ Pocket Option يعمل")
    else:
        bad("لا يمكن الوصول إلى Pocket Option",
            "قد يكون موقع Pocket Option محظوراً في دولة الـ VPS — جرّب VPS في دولة أخرى")


def main() -> int:
    ver = BASE / "version.txt"
    title = f"تقرير فحص البوت SignalCopier — النسخة {ver.read_text(encoding='utf-8').strip() if ver.exists() else '?'}"
    lines.extend([title, "=" * 40, ""])
    check_python()
    pk = check_packages()
    check_env()
    if pk:
        check_mongo()
    check_port()
    check_internet()
    log = BASE / "bot.log"
    if log.exists():
        tail = log.read_text(encoding="utf-8", errors="replace").splitlines()[-25:]
        lines.extend(["", "آخر أسطر من سجل البوت bot.log:", "-" * 40, *tail])
    lines.insert(2, "النتيجة: كل شيء جاهز" if problems == 0 else f"النتيجة: يوجد {problems} مشكلة — الحلول مكتوبة تحت كل مشكلة")
    REPORT.write_text("\n".join(lines) + "\n", encoding="utf-8-sig")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
