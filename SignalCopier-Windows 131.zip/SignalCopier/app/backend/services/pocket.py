"""Single Pocket Option connection (unofficial websocket API via BinaryOptionsToolsV2)."""

import asyncio
import json
import logging
from contextlib import suppress
from typing import Optional

from BinaryOptionsToolsV2.pocketoption import PocketOptionAsync

from lib.db import db

logger = logging.getLogger(__name__)


def ssid_mode(ssid: str) -> str:
    """Read isDemo from a `42["auth",{...}]` payload. Defaults to demo."""
    try:
        payload = json.loads(ssid[ssid.index("["):])
        return "demo" if int(payload[1].get("isDemo", 1)) == 1 else "real"
    except Exception:
        return "demo"


class PocketManager:
    def __init__(self) -> None:
        self.api: Optional[PocketOptionAsync] = None
        self.mode: str = "demo"
        self.balance: Optional[float] = None
        self.error: Optional[str] = None
        self.lock = asyncio.Lock()
        self.has_ssid = False  # a saved SSID exists — watchdog keeps trying to connect it

    async def _doc(self) -> dict:
        return await db.config.find_one({"id": "pocket"}, {"_id": 0}) or {}

    async def restore(self) -> None:
        doc = await self._doc()
        self.mode = doc.get("mode", "demo")
        ssid = doc.get(f"ssid_{self.mode}")
        self.has_ssid = bool(ssid)
        if ssid:
            try:
                await self._open(ssid)
            except Exception as exc:  # noqa: BLE001
                self.error = f"تعذّر الاتصال بالـ SSID المحفوظ: {exc}"

    async def _close(self) -> None:
        if self.api is not None:
            with suppress(Exception):
                await asyncio.wait_for(self.api.shutdown(), 10)
        self.api = None

    async def _open(self, ssid: str) -> None:
        async with self.lock:
            await self._close()
            api = PocketOptionAsync(ssid=ssid)
            try:
                await asyncio.wait_for(api.wait_for_assets(timeout=25), 30)
                bal = await asyncio.wait_for(api.balance(), 10)
                if bal is None or bal < 0:
                    raise RuntimeError("لم يتم استلام الرصيد — الـ SSID غير صالح أو منتهي")
            except Exception:
                with suppress(Exception):
                    await asyncio.wait_for(api.shutdown(), 10)
                raise
            self.api, self.balance, self.error = api, float(bal), None

    async def connect(self, ssid: str) -> str:
        ssid = ssid.strip().strip("'\"").strip()
        mode = ssid_mode(ssid)
        try:
            await self._open(ssid)
        except asyncio.TimeoutError as exc:
            self.error = "انتهت مهلة الاتصال — تأكد من نسخ رسالة auth كاملة وحديثة"
            raise RuntimeError(self.error) from exc
        except Exception as exc:  # noqa: BLE001
            self.error = str(exc) or "فشل الاتصال"
            raise RuntimeError(self.error) from exc
        self.mode, self.has_ssid = mode, True
        await db.config.update_one(
            {"id": "pocket"}, {"$set": {"id": "pocket", f"ssid_{mode}": ssid, "mode": mode}}, upsert=True
        )
        return mode

    async def switch_mode(self, mode: str) -> None:
        doc = await self._doc()
        ssid = doc.get(f"ssid_{mode}")
        if not ssid:
            raise RuntimeError("لا يوجد SSID محفوظ لهذا الحساب — أضفه أولًا")
        try:
            await self._open(ssid)
        except Exception as exc:  # noqa: BLE001
            self.error = str(exc) or "فشل الاتصال"
            raise RuntimeError(f"تعذّر الاتصال: {self.error}") from exc
        self.mode = mode
        await db.config.update_one({"id": "pocket"}, {"$set": {"mode": mode}}, upsert=True)

    async def disconnect(self) -> None:
        async with self.lock:
            await self._close()
        self.balance, self.has_ssid = None, False
        await db.config.delete_one({"id": "pocket"})

    def connected(self) -> bool:
        if self.api is None:
            return False
        try:
            return bool(self.api.is_connected())
        except Exception:  # noqa: BLE001
            return False

    async def refresh_balance(self) -> Optional[float]:
        if self.api is None:
            return None
        with suppress(Exception):
            bal = await asyncio.wait_for(self.api.balance(), 5)
            if bal is not None and bal >= 0:
                self.balance = float(bal)
        return self.balance

    async def status(self) -> dict:
        doc = await self._doc()
        await self.refresh_balance()
        return {
            "connected": self.connected(),
            "mode": self.mode,
            "balance": self.balance,
            "has_demo": bool(doc.get("ssid_demo")),
            "has_real": bool(doc.get("ssid_real")),
            "error": self.error,
        }

    async def ensure_connected(self) -> None:
        """Watchdog: reconnect a dropped websocket and keep the cached balance fresh."""
        if self.lock.locked():
            return
        if self.api is None:
            if self.has_ssid:  # boot-time connect failed (no internet yet) — try again
                with suppress(Exception):
                    await self.restore()
            return
        if not self.connected():
            with suppress(Exception):
                await asyncio.wait_for(self.api.reconnect(), 20)
                logger.info("pocket option reconnected")
        await self.refresh_balance()

    async def payout(self, asset: str) -> Optional[int]:
        if self.api is None:
            return None
        with suppress(Exception):
            return await asyncio.wait_for(self.api.payout(asset), 10)
        return None

    async def place(self, asset: str, direction: str, amount: float, duration: int) -> str:
        if self.api is None:
            raise RuntimeError("Pocket Option غير متصل")
        fn = self.api.buy if direction == "call" else self.api.sell
        trade_id, _ = await asyncio.wait_for(fn(asset, amount, duration), 20)
        return str(trade_id)

    async def result(self, trade_id: str, duration: int) -> dict:
        if self.api is None:
            raise RuntimeError("Pocket Option غير متصل")
        # hard outer bound so a stalled socket can never leave a trade pending forever
        res = await asyncio.wait_for(self.api.check_win(trade_id, timeout_seconds=duration + 120), duration + 150)
        return dict(res)


pocket = PocketManager()
