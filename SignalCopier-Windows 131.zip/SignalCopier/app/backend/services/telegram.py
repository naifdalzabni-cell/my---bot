"""Telegram user-account client (Telethon) — QR / code login, chat selection, live listener."""

import asyncio
import logging
import os
from contextlib import suppress
from datetime import datetime, timedelta, timezone
from typing import Optional

from telethon import TelegramClient, events, types
from telethon.errors import (
    ApiIdInvalidError,
    FloodWaitError,
    PasswordHashInvalidError,
    PhoneCodeExpiredError,
    PhoneCodeInvalidError,
    PhoneNumberInvalidError,
    SessionPasswordNeededError,
)
from telethon.sessions import StringSession

from lib.db import db
from services import engine

logger = logging.getLogger(__name__)

# Public desktop-client app identity, used for QR login so the user doesn't need my.telegram.org
DEFAULT_API_ID = int(os.environ.get("TG_DEFAULT_API_ID", "2040"))
DEFAULT_API_HASH = os.environ.get("TG_DEFAULT_API_HASH", "b18441a1ff607e10a989891a5462e627")
QR_TOTAL_SECONDS = 300


class TgError(Exception):
    pass


def _make_client(session: str, api_id: int, api_hash: str) -> TelegramClient:
    return TelegramClient(
        StringSession(session), api_id, api_hash,
        device_model="Signal Copier PC", system_version="Windows 10", app_version="5.6.3",
        lang_code="ar", system_lang_code="ar",
    )


class TelegramManager:
    def __init__(self) -> None:
        self.client: Optional[TelegramClient] = None
        self.authorized = False
        self.account_name: Optional[str] = None
        self.username: Optional[str] = None
        self.phone: Optional[str] = None
        self.api_id: Optional[int] = None
        self.api_hash: Optional[str] = None
        self.phone_code_hash: Optional[str] = None
        self.needs_password = False
        self.selected: dict[int, str] = {}
        self.favorites: set[int] = set()
        self.dialog_cache: Optional[list[dict]] = None
        self.has_session = False
        self._seen: dict[tuple[int, int], None] = {}  # (chat_id, msg_id) — guards against replayed updates
        # QR login state
        self._qr = None
        self.qr_task: Optional[asyncio.Task] = None
        self.qr_state: str = "idle"  # idle / waiting / password / success / expired / error
        self.qr_url: Optional[str] = None
        self.qr_expires: Optional[datetime] = None
        self.qr_error: Optional[str] = None

    async def _doc(self) -> dict:
        return await db.config.find_one({"id": "telegram"}, {"_id": 0}) or {}

    async def restore(self) -> None:
        doc = await self._doc()
        self.has_session = bool(doc.get("session"))
        self.selected = {c["id"]: c["title"] for c in doc.get("chats", [])}
        self.favorites = set(doc.get("favorites", []))
        self.phone = doc.get("phone")
        self.api_id, self.api_hash = doc.get("api_id"), doc.get("api_hash")
        self.has_session = bool(doc.get("session"))
        if not self.has_session:
            return
        await self.close()
        try:
            self.client = _make_client(doc["session"], doc["api_id"], doc["api_hash"])
            await self.client.connect()
            if await self.client.is_user_authorized():
                await self._on_authorized()
            else:
                self.authorized = False
                self.has_session = False  # session revoked from the phone — needs a new QR login
                await self.close()
        except Exception:  # noqa: BLE001
            logger.exception("telegram restore failed")

    async def _on_authorized(self) -> None:
        assert self.client
        self.authorized = True
        me = await self.client.get_me()
        self.account_name = " ".join(x for x in [me.first_name, me.last_name] if x) or me.username
        self.username = me.username
        if me.phone:
            self.phone = f"+{me.phone}"
        self.client.remove_event_handler(self._on_message)
        self.client.add_event_handler(self._on_message, events.NewMessage())
        with suppress(Exception):
            await self.client.get_dialogs(limit=300)  # warms entity cache so channel updates arrive

    async def _finish_login(self) -> None:
        assert self.client
        self.has_session = True
        await db.config.update_one({"id": "telegram"}, {"$set": {
            "id": "telegram", "api_id": self.api_id, "api_hash": self.api_hash,
            "session": self.client.session.save(),
        }}, upsert=True)
        self.phone_code_hash, self.needs_password = None, False
        await self._on_authorized()
        await db.config.update_one({"id": "telegram"}, {"$set": {"phone": self.phone}})

    async def _on_message(self, event) -> None:
        t0 = asyncio.get_running_loop().time()  # receipt time — latency is measured from here
        if event.chat_id not in self.selected:
            return
        key = (event.chat_id, event.id)
        if key in self._seen:
            return  # same message delivered twice (e.g. after a reconnect) — never trade it twice
        self._seen[key] = None
        if len(self._seen) > 5000:
            self._seen.pop(next(iter(self._seen)))
        if event.message.date and datetime.now(timezone.utc) - event.message.date > timedelta(seconds=120):
            return  # never act on old messages
        if event.message.media is not None and not isinstance(event.message.media, types.MessageMediaWebPage):
            return  # photos, videos, files: results / ads — never a signal
        text = event.raw_text or ""
        if not text.strip():
            return
        try:
            await engine.handle_message(event.chat_id, self.selected[event.chat_id], text, t0=t0)
        except Exception:  # noqa: BLE001
            logger.exception("handle_message failed")

    # ---------- QR login ----------
    async def _cancel_qr(self) -> None:
        if self.qr_task and not self.qr_task.done():
            self.qr_task.cancel()
            with suppress(asyncio.CancelledError, Exception):
                await self.qr_task
        self.qr_task, self._qr = None, None

    def _set_qr(self) -> None:
        self.qr_url = self._qr.url
        exp = self._qr.expires
        self.qr_expires = exp if exp.tzinfo else exp.replace(tzinfo=timezone.utc)

    async def qr_start(self) -> None:
        await self._cancel_qr()
        await self.close()
        self.authorized, self.needs_password, self.qr_error = False, False, None
        self.api_id, self.api_hash = DEFAULT_API_ID, DEFAULT_API_HASH
        self.client = _make_client("", self.api_id, self.api_hash)
        await self.client.connect()
        self._qr = await self.client.qr_login()
        self._set_qr()
        self.qr_state = "waiting"
        self.qr_task = asyncio.create_task(self._qr_wait())

    async def _qr_wait(self) -> None:
        loop = asyncio.get_running_loop()
        deadline = loop.time() + QR_TOTAL_SECONDS
        while True:
            try:
                await self._qr.wait()
                await self._finish_login()
                self.qr_state = "success"
                return
            except asyncio.TimeoutError:
                if loop.time() > deadline:
                    self.qr_state = "expired"
                    return
                await self._qr.recreate()
                self._set_qr()
            except SessionPasswordNeededError:
                self.needs_password = True
                self.qr_state = "password"
                return
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                logger.exception("qr login failed")
                self.qr_state, self.qr_error = "error", str(exc)
                return

    async def submit_password(self, password: str) -> None:
        if not self.client or not self.needs_password:
            raise TgError("لا يوجد تسجيل دخول بانتظار كلمة المرور")
        try:
            await self.client.sign_in(password=password)
        except PasswordHashInvalidError as exc:
            raise TgError("كلمة مرور التحقق بخطوتين غير صحيحة") from exc
        await self._finish_login()
        self.qr_state = "success"

    def qr_status(self) -> dict:
        return {
            "state": self.qr_state, "url": self.qr_url if self.qr_state == "waiting" else None,
            "expires_at": self.qr_expires, "error": self.qr_error,
        }

    # ---------- phone + code login (alternative) ----------
    async def send_code(self, api_id: int, api_hash: str, phone: str) -> None:
        await self._cancel_qr()
        await self.close()
        self.authorized, self.needs_password = False, False
        self.api_id, self.api_hash, self.phone = api_id, api_hash.strip(), phone.strip().replace(" ", "")
        self.client = _make_client("", self.api_id, self.api_hash)
        await self.client.connect()
        try:
            sent = await self.client.send_code_request(self.phone)
        except ApiIdInvalidError as exc:
            raise TgError("api_id أو api_hash غير صحيح") from exc
        except PhoneNumberInvalidError as exc:
            raise TgError("رقم الهاتف غير صحيح — اكتبه بالصيغة الدولية مثل ‎+9665xxxxxxx") from exc
        except FloodWaitError as exc:
            raise TgError(f"طلبات كثيرة — انتظر {exc.seconds} ثانية") from exc
        self.phone_code_hash = sent.phone_code_hash

    async def verify(self, code: str, password: Optional[str]) -> bool:
        """Returns True when signed in, False when a 2FA password is still needed."""
        if not self.client or not self.phone_code_hash:
            raise TgError("اطلب كود الدخول أولًا")
        try:
            if self.needs_password:
                if not password:
                    return False
                await self.client.sign_in(password=password)
            else:
                try:
                    await self.client.sign_in(phone=self.phone, code=code.strip(), phone_code_hash=self.phone_code_hash)
                except SessionPasswordNeededError:
                    self.needs_password = True
                    if not password:
                        return False
                    await self.client.sign_in(password=password)
        except PhoneCodeInvalidError as exc:
            raise TgError("الكود غير صحيح") from exc
        except PhoneCodeExpiredError as exc:
            raise TgError("انتهت صلاحية الكود — اطلب كودًا جديدًا") from exc
        except PasswordHashInvalidError as exc:
            raise TgError("كلمة مرور التحقق بخطوتين غير صحيحة") from exc
        await self._finish_login()
        return True

    # ---------- chats ----------
    async def dialogs(self, refresh: bool = False) -> list[dict]:
        if not self.client or not self.authorized:
            raise TgError("تيليجرام غير متصل")
        if self.dialog_cache is not None and not refresh:
            return self.dialog_cache
        out = []
        async for d in self.client.iter_dialogs(limit=500):
            ent = d.entity
            is_bot = bool(d.is_user and getattr(ent, "bot", False))
            if not (d.is_group or d.is_channel or is_bot):
                continue
            out.append({
                "id": d.id,
                "title": d.title or str(d.id),
                "kind": "bot" if is_bot else ("group" if d.is_group else "channel"),
                "username": getattr(ent, "username", None),
                "members": getattr(ent, "participants_count", None),
            })
        self.dialog_cache = out
        return out

    async def set_chats(self, chats: list[dict]) -> None:
        self.selected = {c["id"]: c["title"] for c in chats}
        await db.config.update_one({"id": "telegram"}, {"$set": {"id": "telegram", "chats": chats}}, upsert=True)

    async def set_favorites(self, ids: list[int]) -> None:
        self.favorites = set(ids)
        await db.config.update_one({"id": "telegram"}, {"$set": {"id": "telegram", "favorites": ids}}, upsert=True)

    async def logout(self) -> None:
        await self._cancel_qr()
        if self.client and self.authorized:
            with suppress(Exception):
                await asyncio.wait_for(self.client.log_out(), 10)
        await self.close()
        self.authorized, self.account_name, self.username = False, None, None
        self.selected, self.favorites, self.dialog_cache = {}, set(), None
        self.has_session = False
        self.qr_state = "idle"
        await db.config.delete_one({"id": "telegram"})

    async def close(self) -> None:
        if self.client:
            with suppress(Exception):
                await asyncio.wait_for(self.client.disconnect(), 10)
        self.client = None

    async def ensure_connected(self) -> None:
        """Watchdog: reconnect a dropped (but authorized) session so no signal is missed."""
        if self.qr_task and not self.qr_task.done():
            return  # a login is in progress
        if self.client and self.authorized and not self.client.is_connected():
            with suppress(Exception):
                await asyncio.wait_for(self.client.connect(), 15)
                logger.info("telegram reconnected")
        elif self.has_session and not self.authorized:
            # restore failed earlier (network blip at boot) — keep retrying instead of staying deaf
            with suppress(Exception):
                await asyncio.wait_for(self.restore(), 30)
                if self.authorized:
                    logger.info("telegram session restored by watchdog")

    async def shutdown(self) -> None:
        await self._cancel_qr()
        await self.close()

    def status(self) -> dict:
        return {
            "has_credentials": bool(self.api_id),
            "authorized": self.authorized,
            "connected": bool(self.client and self.client.is_connected() and self.authorized),
            "account_name": self.account_name,
            "username": self.username,
            "phone": self.phone,
            "awaiting_code": bool(self.phone_code_hash),
            "selected_chats": [{"id": k, "title": v} for k, v in self.selected.items()],
            "favorites": sorted(self.favorites),
        }


telegram = TelegramManager()
