"""Signal → trade engine: scheduling, risk checks, martingale chain."""

import asyncio
import logging
import uuid
from datetime import datetime, timedelta, timezone
from typing import Optional

from lib.dates import today_iso
from lib.db import db
from lib.parser import parse_signal
from models.schemas import ParsedSignal, Settings
from services.pocket import pocket

logger = logging.getLogger(__name__)

LATE_TOLERANCE = 3  # seconds: a signal that arrives after its entry minute is skipped, never entered late
_tasks: set[asyncio.Task] = set()
# In-memory caches so the hot path (signal → trade) never waits on the database
_settings_cache: Optional[Settings] = None
_rules_cache: Optional[dict[int, dict]] = None
_inserted: dict[str, asyncio.Event] = {}
_inflight_exposure = 0.0  # stake of trades placed but not settled yet — counted against the daily loss limit
PREPARE_LEAD = 2.0  # seconds before a timed entry to run all checks


def _spawn(coro) -> None:
    task = asyncio.create_task(coro)
    _tasks.add(task)
    task.add_done_callback(_tasks.discard)


async def get_settings() -> Settings:
    global _settings_cache
    if _settings_cache is None:
        doc = await db.config.find_one({"id": "settings"}, {"_id": 0, "id": 0})
        s = Settings(**(doc or {}))
        if s.listening_since and s.listening_since.tzinfo is None:
            s.listening_since = s.listening_since.replace(tzinfo=timezone.utc)
        _settings_cache = s
    return _settings_cache.model_copy()


async def save_settings(s: Settings) -> Settings:
    prev = await get_settings()
    if s.bot_enabled and not prev.bot_enabled:
        s.listening_since = datetime.now(timezone.utc)
    elif not s.bot_enabled:
        s.listening_since = None
    else:
        s.listening_since = prev.listening_since
    s.ignore_keywords = [k.strip() for k in s.ignore_keywords if k.strip()]
    s.require_keywords = [k.strip() for k in s.require_keywords if k.strip()]
    await db.config.update_one({"id": "settings"}, {"$set": {"id": "settings", **s.model_dump()}}, upsert=True)
    global _settings_cache
    _settings_cache = s.model_copy()
    return s


async def get_rules() -> dict[int, dict]:
    global _rules_cache
    if _rules_cache is None:
        doc = await db.config.find_one({"id": "channel_rules"}, {"_id": 0}) or {}
        _rules_cache = {int(k): v for k, v in (doc.get("rules") or {}).items()}
    return dict(_rules_cache)


def invalidate_rules() -> None:
    global _rules_cache
    _rules_cache = None


async def effective_settings(chat_id: Optional[int]) -> Settings:
    """Global settings with the channel's own amount/martingale overrides applied."""
    s = await get_settings()
    if chat_id is None:
        return s
    rule = (await get_rules()).get(chat_id)
    if not rule:
        return s
    return s.model_copy(update={k: v for k, v in rule.items() if v is not None and k != "chat_id"})


def keyword_block(text: str, s: Settings, needs_required: bool) -> Optional[str]:
    low = text.lower()
    for k in s.ignore_keywords:
        if k.lower() in low:
            return f"تم التجاهل: تحتوي الكلمة المحظورة «{k}»"
    if needs_required and s.require_keywords and not any(k.lower() in low for k in s.require_keywords):
        return "تم التجاهل: لا تحتوي أي كلمة مطلوبة"
    return None


async def today_pnl() -> float:
    rows = await db.trades.find({"day": today_iso()}, {"_id": 0, "profit": 1}).to_list(5000)
    return round(sum(r.get("profit", 0) for r in rows), 2)


def step_amount(s: Settings, step: int) -> float:
    if step == 0:
        return s.amount
    if s.martingale_mode == "manual" and len(s.martingale_amounts) >= step:
        return round(s.martingale_amounts[step - 1], 2)
    return round(s.amount * (s.martingale_multiplier**step), 2)


async def _set_signal(signal_id: str, action: str, note: str) -> None:
    ev = _inserted.get(signal_id)
    if ev is not None:
        await ev.wait()  # make sure the signal row exists before updating it
    await db.signals.update_one({"id": signal_id}, {"$set": {"action": action, "note": note}})


def _delay_for(entry_time: str, s: Settings) -> tuple[Optional[float], str]:
    """Seconds to wait before entering (0 = now) or None to skip."""
    tz = timezone(timedelta(hours=s.signal_utc_offset))
    now = datetime.now(tz)
    h, m = (int(x) for x in entry_time.split(":"))
    target = now.replace(hour=h % 24, minute=m % 60, second=0, microsecond=0)
    diff = (target - now).total_seconds()
    if diff > 12 * 3600:
        diff -= 86400
    elif diff < -12 * 3600:
        diff += 86400
    if diff < -LATE_TOLERANCE:
        if diff < -300:
            return None, f"وقت الدخول {entry_time} لا يطابق الوقت الحالي — تحقق من «توقيت الإشارات (UTC±)» في الإعدادات"
        return None, f"وصلت التوصية متأخرة: وقت الدخول {entry_time} مضى — لم تُفتح صفقة"
    if diff <= 0:
        return 0, f"وقت الدخول {entry_time} الآن — تنفيذ فوري"
    if diff > s.max_wait_minutes * 60:
        return None, f"وقت الدخول {entry_time} بعيد ({int(diff // 60)} دقيقة) — تحقق من «توقيت الإشارات (UTC±)» في الإعدادات"
    return diff, f"مجدولة للدخول في {entry_time}"


async def handle_message(chat_id: int, chat_title: str, text: str, t0: Optional[float] = None) -> None:
    t0 = t0 if t0 is not None else asyncio.get_running_loop().time()
    parsed = parse_signal(text)
    s = await get_settings()
    now = datetime.now(timezone.utc)
    action, note = "ignored", ""
    run: Optional[tuple[str, str, int, float]] = None  # asset, direction, duration, delay
    blocked = keyword_block(text, s, parsed.kind == "full") if parsed.kind != "ignored" else None

    if blocked:
        action, note = "ignored", blocked
    elif parsed.kind == "ignored":
        note = parsed.explanation
    elif parsed.kind == "full" and parsed.entry_time and parsed.duration and parsed.asset and parsed.direction:
        delay, note = _delay_for(parsed.entry_time, s)
        if delay is None:
            action = "skipped"
        else:
            run = (parsed.asset, parsed.direction, parsed.duration, delay)

    if run:
        if not s.bot_enabled:
            action, note, run = "skipped", "البوت متوقف", None
        else:
            action = "scheduled" if run[3] > 0 else "executing"
            note = note if run[3] > 0 else "جارٍ التنفيذ"

    signal_id = str(uuid.uuid4())
    logger.info("رسالة من «%s» → %s | %s | النص: %s", chat_title, action, note, " / ".join(text.split("\n"))[:300])
    if run:  # start the trade first; the signal row is written in parallel
        ev = _inserted[signal_id] = asyncio.Event()
        _spawn(run_signal(signal_id, chat_id, chat_title, *run, t0=t0))
    try:
        await db.signals.insert_one({
            "id": signal_id, "chat_id": chat_id, "chat_title": chat_title, "text": text[:2000],
            "parsed": parsed.model_dump(), "action": action, "note": note, "received_at": now, "day": today_iso(),
        })
    finally:
        if run:
            ev.set()


async def run_signal(
    signal_id: str, chat_id: int, chat_title: str, asset: str, direction: str, duration: int, delay: float,
    t0: Optional[float] = None,
) -> None:
    loop = asyncio.get_running_loop()
    t0 = t0 if t0 is not None else loop.time()
    fire_at: Optional[float] = None
    try:
        if delay > 0:
            fire_at = t0 + delay
            await asyncio.sleep(max(0.0, delay - PREPARE_LEAD))  # wake early, checks run before the exact second
        await execute_chain(signal_id, asset, direction, duration, chat_id, chat_title, t0=t0, fire_at=fire_at)
    except Exception as exc:  # noqa: BLE001
        logger.exception("signal %s failed", signal_id)
        await _set_signal(signal_id, "error", f"خطأ: {exc}")
    finally:
        _inserted.pop(signal_id, None)


async def _precheck(s: Settings, asset: str) -> tuple[Optional[str], Optional[int]]:
    if not s.bot_enabled:
        return "البوت متوقف", None
    if not pocket.connected():
        return "Pocket Option غير متصل", None
    pnl, payout = await asyncio.gather(today_pnl(), pocket.payout(asset))
    # worst case: every open trade loses — never let a burst of signals overshoot the limit
    if s.daily_loss_limit > 0 and pnl - _inflight_exposure - s.amount < -s.daily_loss_limit - 1e-9:
        return f"حد الخسارة اليومي: الربح {pnl} والصفقات المفتوحة {_inflight_exposure} — تم الإيقاف", None
    if s.daily_profit_target > 0 and pnl >= s.daily_profit_target:
        return f"تم بلوغ هدف الربح اليومي ({pnl})", None
    if payout is None:
        return f"الزوج {asset} غير متاح حاليًا", None
    if payout < s.min_payout:
        return f"العائد {payout}% أقل من الحد الأدنى {s.min_payout}%", payout
    bal = pocket.balance  # kept fresh by the watchdog — no network wait here
    if bal is not None and bal < s.amount:
        return "الرصيد غير كافٍ", payout
    if not (await get_settings()).bot_enabled:  # switched off while we were checking
        return "البوت متوقف", None
    return None, payout


async def execute_chain(
    signal_id: Optional[str], asset: str, direction: str, duration: int,
    chat_id: Optional[int] = None, chat_title: Optional[str] = None,
    t0: Optional[float] = None, fire_at: Optional[float] = None,
) -> None:
    global _inflight_exposure
    loop = asyncio.get_running_loop()
    s = await effective_settings(chat_id)
    reason, payout = await _precheck(s, asset)
    if reason:
        if signal_id:
            await _set_signal(signal_id, "skipped", reason)
        return
    if fire_at is not None:
        await asyncio.sleep(max(0.0, fire_at - loop.time()))
    start = fire_at if fire_at is not None else (t0 if t0 is not None else loop.time())
    step = 0
    while True:
        amount = step_amount(s, step)
        trade_id = str(uuid.uuid4())
        doc = {
            "id": trade_id, "signal_id": signal_id, "po_trade_id": None, "asset": asset, "direction": direction,
            "amount": amount, "duration": duration, "payout": payout, "step": step, "mode": pocket.mode,
            "status": "pending", "profit": 0.0, "error": None, "opened_at": datetime.now(timezone.utc),
            "closed_at": None, "day": today_iso(), "chat_id": chat_id, "chat_title": chat_title,
        }
        _inflight_exposure += amount  # reserved synchronously right after the checks
        try:
            doc["po_trade_id"] = await pocket.place(asset, direction, amount, duration)
            doc["latency_ms"] = int((loop.time() - start) * 1000)
        except Exception as exc:  # noqa: BLE001
            _inflight_exposure -= amount
            doc.update(status="error", error=str(exc) or "فشل فتح الصفقة", closed_at=datetime.now(timezone.utc))
            await db.trades.insert_one(doc)
            if signal_id:
                await _set_signal(signal_id, "error", f"فشل فتح الصفقة: {doc['error']}")
            return
        await db.trades.insert_one(doc)
        if signal_id and step == 0:
            await _set_signal(signal_id, "executed", f"تم فتح الصفقة {direction.upper()} بمبلغ {amount} خلال {doc['latency_ms']}ms")

        status, profit = "error", 0.0
        try:
            res = await pocket.result(doc["po_trade_id"], duration)
            status = res.get("result") or "error"
            if status == "win":
                profit = round(amount * (payout or 0) / 100, 2)
            elif status == "loss":
                profit = -amount
        except Exception as exc:  # noqa: BLE001
            doc["error"] = f"تعذّر جلب النتيجة: {exc}"
        await db.trades.update_one({"id": trade_id}, {"$set": {
            "status": status if status in ("win", "loss", "draw") else "error",
            "profit": profit, "error": doc["error"], "closed_at": datetime.now(timezone.utc),
        }})
        _inflight_exposure = max(0.0, _inflight_exposure - amount)
        _spawn(pocket.refresh_balance())

        if status != "loss" or not s.martingale_enabled or step >= s.martingale_steps:
            return
        step += 1
        start = loop.time()
        s = await effective_settings(chat_id)
        if not s.bot_enabled:
            return
        nxt = step_amount(s, step)
        pnl = await today_pnl()
        if s.daily_loss_limit > 0 and pnl - _inflight_exposure - nxt < -s.daily_loss_limit - 1e-9:
            if signal_id:
                await _set_signal(signal_id, "executed", f"أُوقفت المضاعفة عند الخطوة {step}: ستتجاوز حد الخسارة اليومي")
            return
        bal = pocket.balance
        if bal is not None and bal < nxt:
            if signal_id:
                await _set_signal(signal_id, "executed", f"أُلغيت خطوة المضاعفة {step}: الرصيد غير كافٍ")
            return
