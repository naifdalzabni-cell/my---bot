import asyncio
from contextlib import asynccontextmanager, suppress
from fastapi import FastAPI, APIRouter
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
import os
import logging
from pathlib import Path


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
from lib.db import client, db, ensure_indexes  # noqa: E402
from routers.bot import router as bot_router  # noqa: E402
from services.pocket import pocket  # noqa: E402
from services.telegram import telegram  # noqa: E402

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    **({"filename": os.environ["LOG_FILE"], "encoding": "utf-8"} if os.environ.get("LOG_FILE") else {}),
)
logger = logging.getLogger(__name__)


async def _restore_connections():
    # On a PC the bot may boot before the database service is up — wait for it instead of dying.
    while True:
        try:
            await db.command("ping")
            break
        except Exception:  # noqa: BLE001
            logger.warning("database not ready yet — retrying in 3s")
            await asyncio.sleep(3)
    for svc in (telegram, pocket):
        try:
            await svc.restore()
        except Exception:  # noqa: BLE001
            logger.exception("restore failed — the watchdog will retry")
    while True:  # watchdog: keep both connections warm and ready
        await asyncio.sleep(10)
        try:
            await asyncio.gather(telegram.ensure_connected(), pocket.ensure_connected())
        except Exception:  # noqa: BLE001
            logger.exception("watchdog")


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.index_task = asyncio.create_task(ensure_indexes())  # background: a big index build must not block boot
    app.state.restore_task = asyncio.create_task(_restore_connections())
    yield
    for t in (app.state.index_task, app.state.restore_task):
        t.cancel()
        with suppress(asyncio.CancelledError, Exception):
            await t
    await telegram.shutdown()
    with suppress(Exception):
        await pocket._close()
    client.close()


app = FastAPI(lifespan=lifespan)

api_router = APIRouter(prefix="/api")


@api_router.get("/")
async def root():
    return {"message": "Signal copier API"}


api_router.include_router(bot_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include the router in the main app
app.include_router(api_router)

# Local/Windows mode only: serve the built dashboard from the same process (http://localhost:8001).
# Mounted after the API so /api/* always wins. Unset in the preview — Vite serves the frontend there.
_web_dir = os.environ.get("SERVE_FRONTEND_DIR")
if _web_dir and Path(_web_dir).is_dir():
    from starlette.exceptions import HTTPException as StarletteHTTPException
    from starlette.staticfiles import StaticFiles

    class _SPAStatic(StaticFiles):
        async def get_response(self, path, scope):
            try:
                return await super().get_response(path, scope)
            except StarletteHTTPException as exc:
                if exc.status_code == 404 and not path.startswith("api"):
                    return await super().get_response("index.html", scope)
                raise

    app.mount("/", _SPAStatic(directory=_web_dir, html=True), name="web")
