from datetime import datetime
from typing import Literal, Optional

from pydantic import BaseModel, Field


# ---------- Settings ----------
class Settings(BaseModel):
    bot_enabled: bool = False
    amount: float = 1.0
    default_duration: int = 60  # seconds, used when the signal has no timeframe
    min_payout: int = 80
    daily_loss_limit: float = 0  # 0 = off
    daily_profit_target: float = 0  # 0 = off
    signal_utc_offset: float = 0  # timezone of the "Time:" field in the signals (hours)
    max_wait_minutes: int = 30
    martingale_enabled: bool = False
    martingale_steps: int = 2
    martingale_mode: Literal["multiplier", "manual"] = "multiplier"
    martingale_multiplier: float = 2.2
    martingale_amounts: list[float] = Field(default_factory=list)
    ignore_keywords: list[str] = Field(default_factory=list)  # message containing any → ignored
    require_keywords: list[str] = Field(default_factory=list)  # if set, signal must contain one
    listening_since: Optional[datetime] = None  # set by the server when the bot is switched on


# ---------- Per-channel rules (None = use global setting) ----------
class ChannelRuleIn(BaseModel):
    amount: Optional[float] = Field(default=None, gt=0)
    martingale_enabled: Optional[bool] = None
    martingale_steps: Optional[int] = Field(default=None, ge=0, le=10)
    martingale_mode: Optional[Literal["multiplier", "manual"]] = None
    martingale_multiplier: Optional[float] = Field(default=None, gt=0)
    martingale_amounts: Optional[list[float]] = None


class ChannelRule(ChannelRuleIn):
    chat_id: int


class ChannelStat(BaseModel):
    chat_id: int
    chat_title: str
    signals: int
    trades: int
    wins: int
    losses: int
    draws: int
    win_rate: float  # per trade
    first_entry_win_rate: float  # signals won on the first entry
    chain_win_rate: float  # signals won including martingale
    pnl: float
    has_rule: bool


# ---------- Telegram ----------
class ChatRef(BaseModel):
    id: int
    title: str


class TelegramStatus(BaseModel):
    has_credentials: bool
    authorized: bool
    connected: bool
    account_name: Optional[str] = None
    username: Optional[str] = None
    phone: Optional[str] = None
    awaiting_code: bool = False
    selected_chats: list[ChatRef] = Field(default_factory=list)
    favorites: list[int] = Field(default_factory=list)


class QrStatus(BaseModel):
    state: Literal["idle", "waiting", "password", "success", "expired", "error"]
    url: Optional[str] = None
    expires_at: Optional[datetime] = None
    error: Optional[str] = None


class TelegramPassword(BaseModel):
    password: str = Field(min_length=1, max_length=256)


class FavoritesIn(BaseModel):
    ids: list[int]


class TelegramSendCode(BaseModel):
    api_id: int = Field(gt=0)
    api_hash: str = Field(min_length=10, max_length=64)
    phone: str = Field(min_length=5, max_length=20)


class TelegramVerify(BaseModel):
    code: str = Field(min_length=3, max_length=10)
    password: Optional[str] = None


class TelegramVerifyResult(BaseModel):
    ok: bool
    needs_password: bool = False


class Dialog(BaseModel):
    id: int
    title: str
    kind: Literal["channel", "group", "bot"]
    username: Optional[str] = None
    members: Optional[int] = None


class ChatSelection(BaseModel):
    chats: list[ChatRef]


# ---------- Pocket Option ----------
class PocketStatus(BaseModel):
    connected: bool
    mode: Literal["demo", "real"]
    balance: Optional[float] = None
    has_demo: bool = False
    has_real: bool = False
    error: Optional[str] = None


class PocketConnect(BaseModel):
    ssid: str = Field(min_length=10, max_length=20000)


class PocketMode(BaseModel):
    mode: Literal["demo", "real"]


class StatusOut(BaseModel):
    telegram: TelegramStatus
    pocket: PocketStatus
    bot_enabled: bool
    server_time: datetime


# ---------- Signals / trades ----------
class ParsedSignal(BaseModel):
    kind: Literal["full", "announce", "confirm", "ignored"]
    asset: Optional[str] = None  # Pocket Option symbol e.g. AEDCNY_otc
    pair_label: Optional[str] = None  # e.g. AED/CNY OTC
    direction: Optional[Literal["call", "put"]] = None
    duration: Optional[int] = None  # seconds
    entry_time: Optional[str] = None  # HH:MM as written in the signal
    explanation: str


class ParseRequest(BaseModel):
    text: str = Field(min_length=1, max_length=4000)


class Signal(BaseModel):
    id: str
    chat_id: int
    chat_title: str
    text: str
    parsed: ParsedSignal
    action: str  # executed / scheduled / skipped / waiting / ignored
    note: str = ""
    received_at: datetime


class Trade(BaseModel):
    id: str
    signal_id: Optional[str] = None
    chat_id: Optional[int] = None
    chat_title: Optional[str] = None
    po_trade_id: Optional[str] = None
    asset: str
    direction: Literal["call", "put"]
    amount: float
    duration: int
    payout: Optional[int] = None
    step: int = 0  # 0 = first entry, 1.. = martingale steps
    mode: Literal["demo", "real"]
    status: Literal["pending", "win", "loss", "draw", "error"]
    profit: float = 0
    error: Optional[str] = None
    latency_ms: Optional[int] = None  # signal received → order confirmed by Pocket Option
    opened_at: datetime
    closed_at: Optional[datetime] = None


class Stats(BaseModel):
    day: str
    pnl: float
    wins: int
    losses: int
    draws: int
    win_rate: float
    trades_count: int
    signals_count: int
    pending: int
    avg_latency_ms: Optional[int] = None
    last_latency_ms: Optional[int] = None
