"""Export / import all bot settings (+ trade history) to one file. Usage: backup.py export <file> | import <file>"""

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

from bson import json_util
from dotenv import load_dotenv
from pymongo import MongoClient, UpdateOne

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / ".env")
VERSION_FILE = ROOT.parent.parent / "version.txt"
HISTORY = ("signals", "trades")
KNOWN_CONFIG = ("telegram", "pocket", "settings", "channel_rules")


def _db():
    client = MongoClient(os.environ["MONGO_URL"], serverSelectionTimeoutMS=5000)
    client.admin.command("ping")
    return client[os.environ["DB_NAME"]]


def export(path: Path) -> str:
    db = _db()
    data = {
        "app": "SignalCopier", "format": 1,
        "version": VERSION_FILE.read_text(encoding="utf-8").strip() if VERSION_FILE.exists() else "?",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "config": list(db.config.find({}, {"_id": 0})),
        **{c: list(db[c].find({}, {"_id": 0})) for c in HISTORY},
    }
    path.write_text(json_util.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    return f"config={len(data['config'])} signals={len(data['signals'])} trades={len(data['trades'])}"


def restore(path: Path) -> str:
    data = json_util.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(data, dict) or data.get("app") != "SignalCopier" or not isinstance(data.get("config"), list):
        raise ValueError("not a SignalCopier backup")
    db = _db()
    config = [d for d in data["config"] if isinstance(d, dict) and d.get("id")]
    for d in config:
        if d["id"] == "settings":
            d["bot_enabled"] = False  # never trade from two machines at once — user restarts listening manually
    db.config.delete_many({"id": {"$in": [k for k in KNOWN_CONFIG if k not in {d["id"] for d in config}]}})
    for d in config:
        db.config.replace_one({"id": d["id"]}, d, upsert=True)
    counts = []
    for c in HISTORY:
        rows = [r for r in data.get(c) or [] if isinstance(r, dict) and r.get("id")]
        if rows:  # merge by id: keeps anything already on this machine
            db[c].bulk_write([UpdateOne({"id": r["id"]}, {"$set": r}, upsert=True) for r in rows])
        counts.append(f"{c}={len(rows)}")
    return f"config={len(config)} " + " ".join(counts)


if __name__ == "__main__":
    cmd, target = sys.argv[1], Path(sys.argv[2])
    try:
        print("OK " + (export(target) if cmd == "export" else restore(target)))
    except ValueError:
        print("BADFILE")
        sys.exit(3)
    except json.JSONDecodeError:
        print("BADFILE")
        sys.exit(3)
    except Exception as exc:  # noqa: BLE001
        print(f"ERROR {type(exc).__name__}: {exc}")
        sys.exit(2)
