"""Background launcher for Windows (pythonw has no console): logs everything to bot.log."""

import logging
import os
import socket
import sys
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv  # noqa: E402

load_dotenv(ROOT / ".env")
LOG_FILE = os.environ.get("LOG_FILE") or str(ROOT.parent.parent / "bot.log")
HOST, PORT = "127.0.0.1", int(os.environ.get("PORT", "8001"))

# pythonw sets stdout/stderr to None — uvicorn and libraries crash on that, so point them at the log
_log_stream = open(LOG_FILE, "a", encoding="utf-8", buffering=1)
if sys.stdout is None:
    sys.stdout = _log_stream
if sys.stderr is None:
    sys.stderr = _log_stream

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler(_log_stream)],
)
log = logging.getLogger("launcher")


def _port_busy() -> bool:
    with socket.socket() as s:
        s.settimeout(1)
        return s.connect_ex((HOST, PORT)) == 0


def main() -> None:
    ver_file = ROOT.parent.parent / "version.txt"
    ver = ver_file.read_text(encoding="utf-8").strip() if ver_file.exists() else "?"
    log.info("==== تشغيل البوت — النسخة %s (Python %s) ====", ver, sys.version.split()[0])
    if _port_busy():
        log.error("المنفذ %s مستخدم — البوت يعمل غالباً مسبقاً، أو برنامج آخر يستخدم نفس المنفذ. شغّل stop.bat ثم start.bat", PORT)
        return
    import uvicorn

    log.info("تحميل البوت...")
    from server import app  # import here so import errors are written to bot.log

    log.info("البوت يعمل — لوحة التحكم: http://localhost:%s", PORT)
    uvicorn.run(app, host=HOST, port=PORT, log_config=None, access_log=False)


if __name__ == "__main__":
    try:
        main()
    except BaseException as exc:  # noqa: BLE001
        if not isinstance(exc, (KeyboardInterrupt, SystemExit)):
            log.error("توقف البوت بسبب خطأ — شغّل check.bat لمعرفة السبب\n%s", traceback.format_exc())
        raise
